from matplotlib.style import library
from setuptools import setup

setup(name='string_dtm',
        version='0.2.0',
        description='Handeling strings in datetime',
        packages=['string_dtm'],
        author_email='ranjitmaity95@gmail.com',
        zip_safe=False,
        long_description="If You importing your data from a .csv file ,might be some time you can get the error as improper format  for date time library then you can use this library to convert to a suitable format for your data",
        classifiers=['Programming Language :: Python :: 3.6'],
        )