from setuptools import setup

setup(name='string_dt',
        version='0.1',
        description='Handeling strings in datetime',
        packages=['string_dtm'],
        author_email='ranjitmaity95@gmail.com',
        zip_safe=False)